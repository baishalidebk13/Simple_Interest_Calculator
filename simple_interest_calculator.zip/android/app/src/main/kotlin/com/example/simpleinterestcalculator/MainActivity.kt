package com.example.simpleinterestcalculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
